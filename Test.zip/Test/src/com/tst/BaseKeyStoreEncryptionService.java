package com.tst;

/**
 * Stub base class for hashing logic.
 */
public abstract class BaseKeyStoreEncryptionService {
    private String hashAlgorithmName = "SHA-256";

    public void setHashAlgorithmName(String name) {
        this.hashAlgorithmName = name;
    }

    public String getHashAlgorithmName() {
        return hashAlgorithmName;
    }

    public byte[] hash(byte[] input) throws EncryptionServiceException {
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance(hashAlgorithmName);
            return digest.digest(input);
        } catch (Exception e) {
            throw new EncryptionServiceException("Hashing failed", e);
        }
    }

    public abstract byte[] encrypt(byte[] clearText) throws EncryptionServiceException;

    public abstract byte[] decrypt(byte[] encryptedText) throws EncryptionServiceException;
}