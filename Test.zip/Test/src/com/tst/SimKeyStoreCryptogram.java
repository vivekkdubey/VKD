package com.tst;

import java.util.Arrays;

/**
 * Holds encrypted data and the key ID used for encryption.
 */
public class SimKeyStoreCryptogram {
    private final byte[] data;
    private final int keyId;

    public SimKeyStoreCryptogram(byte[] data, int keyId) {
        this.data = data;
        this.keyId = keyId;
    }

    public byte[] getData() {
        return data;
    }

    public int getKeyId() {
        return keyId;
    }

    @Override
    public String toString() {
        return "SimKeyStoreCryptogram{" +
                "data=" + Arrays.toString(data) +
                ", keyId=" + keyId +
                '}';
    }
}