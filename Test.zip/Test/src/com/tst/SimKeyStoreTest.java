package com.tst;

public class SimKeyStoreTest {
    public static void main(String[] args) throws Exception {
        SimulatedKeyStoreAndEncryptionClient client = new SimulatedKeyStoreAndEncryptionClient();

        String message = "Hello Vivek!";
        SimKeyStoreCryptogram cryptogram = client.encrypt(message.getBytes("UTF-8"));

        System.out.println("Encrypted (Base64): " + org.apache.commons.codec.binary.Base64.encodeBase64(cryptogram.getData()));
        System.out.println("Key ID: " + cryptogram.getKeyId());

        byte[] decrypted = client.decrypt(cryptogram);
        System.out.println("Decrypted: " + new String(decrypted, "UTF-8"));
    }
}