
package com.tst;

import java.io.InputStream;
import java.security.spec.KeySpec;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;



import org.apache.commons.codec.binary.Base64;

/**
 * This class simulates the key management of such applications as RSA and
 * StrongKey. It will be used during development to mitigate the need to have
 * every developer install a key management client/application the developer's
 * system.
 * <p>
 * <b>WARNING:</b> The simulated key management package bundled with Oracle
 * Retail applications is not PA-DSS nor PCI-DSS compliant for encrypting and
 * decrypting. It is made available as a convenience for Oracle Retail
 * consultants, integrators, and customers. If you use the simulated key manager
 * you will not be PCI-DSS compliant; therefore, the simulated key manager
 * should be replaced with a compliant key manager.
 *<p>
 * This class is final so it can't be subclassed
 */
public final class SimulatedKeyStoreAndEncryptionClient
{
    /** Logger used for debugging. */
    //protected static final Logger logger = Logger.getLogger(SimulatedKeyStoreAndEncryptionClient.class);
    /** Provider name of the JCE implemented in this class. */
    public static final String DEFAULT_PROVIDER_NAME = "SunJCE";

    protected String[] encryptionKeys   = null;
    protected int lastKeyID             = -1;
    protected String providerName       = DEFAULT_PROVIDER_NAME;
    protected String cipherName         = "DES";
    protected String cipherMode         = "ECB";
    protected String cipherPadding      = "PKCS5PADDING";

    /** keypass */
    public static final String INSTALLER_PHRASE = "installerPhrase";

    /** application properties file **/
    public static final String APPLICATION_PROPERTIES = "application.properties";

    /** key count */
    public static final int KEY_COUNT = 20;

    /** key generation algorithm */
    public static final String KEY_GENERATION_ALGORITHM = "PBEWithMD5AndDES";

    /**
     * Default constructor; initializes the encryption key array.
     */
    public SimulatedKeyStoreAndEncryptionClient()
    {
    }

    /**
     * This method encrypts the clear text using the next key in the array.
     * @param clearText
     * @return byte[] containing encrypted text
     * @exception EncryptionServiceException
     */
    public SimKeyStoreCryptogram encrypt(byte[] clearText) throws Exception
    {
        // Get the encryption key
        int keyID = ++lastKeyID;
        if (keyID >= this.getEncryptionKeys().length)
        {
            keyID = 0;
        }
        lastKeyID = keyID;
        String key = this.getEncryptionKeys()[keyID];

        // Build the cipher
        Cipher cipher = Cipher.getInstance(getCipherAndParameters(), providerName);
        // Cipher cipher = Cipher.getInstance(cipherName);
        byte[] keybytes = Base64.decodeBase64(key.getBytes());
        SecretKeySpec secretkeyspec = new SecretKeySpec(keybytes, cipherName);
        cipher.init(Cipher.ENCRYPT_MODE, secretkeyspec);

        // Encrypt the text
        byte[] encryted = cipher.doFinal(clearText);

        // Build the cryptogram.
        return new SimKeyStoreCryptogram(encryted, keyID);
    }

    /**
     * This method decrypts the encrypted byte array in the cryptogram using
     * the key identified by the key id.
     * @param SimKeyStoreCryptogram
     * @return byte[] containing the original clear text
     * @exception EncryptionServiceException
     */
    public byte[] decrypt(SimKeyStoreCryptogram cryptogram) throws Exception
    {
        // Get the encryption key
        int keyID = cryptogram.getKeyId();
        String key = this.getEncryptionKeys()[keyID];

        // Build the cipher
        Cipher cipher = Cipher.getInstance(getCipherAndParameters(), providerName);
        byte[] keybytes = Base64.decodeBase64(key.getBytes());
        SecretKeySpec secretkeyspec = new SecretKeySpec(keybytes, cipherName);
        cipher.init(Cipher.DECRYPT_MODE, secretkeyspec);

        // Encrypt the text
        byte[] clearText = cipher.doFinal(cryptogram.getData());

        // Build the cryptogram.
        return clearText;
    }

    /**
     * This method builds the cypher/mode/padding value.
     * @return String
     */
    private String getCipherAndParameters()
    {
        String cipherPlus = cipherName;
        if (cipherMode != null && cipherMode.length() > 0)
        {
            cipherPlus = cipherName + "/" + cipherMode;
            if (cipherPadding != null && cipherPadding.length() > 0)
            {
                cipherPlus = cipherName + "/" + cipherMode + "/" + cipherPadding;
            }
        }

        return cipherPlus;
    }

    /**
     * @return Returns the cipherName.
     */
    public String getCipherName()
    {
        return cipherName;
    }

    /**
     * @param cipherName The cipherName to set.
     */
    public void setCipherName(String cipherName)
    {
        this.cipherName = cipherName;
    }

    /**
     * @return Returns the providerName.
     */
    public String getProviderName()
    {
        return providerName;
    }

    /**
     * @param providerName The providerName to set.
     */
    public void setProviderName(String provider)
    {
        this.providerName = provider;
    }
    /**
     * @return Returns the mode.
     */
    public String getCipherMode()
    {
        return cipherMode;
    }

    /**
     * @param mode The mode to set.
     */
    public void setCipherMode(String mode)
    {
        this.cipherMode = mode;
    }

    /**
     * @return Returns the padding.
     */
    public String getCipherPadding()
    {
        return cipherPadding;
    }

    /**
     * @param padding The padding to set.
     */
    public void setCipherPadding(String padding)
    {
        this.cipherPadding = padding;
    }

    /**
     * Lazy init to return the encryption keys.
     * @return
     * @throws EncryptionServiceException
     */
    protected String[] getEncryptionKeys() throws EncryptionServiceException
    {
        if (encryptionKeys == null)
        {
            String installerPhrase = this.getInstallerPhrase();
            if (installerPhrase != null)
            {
                encryptionKeys = new String[KEY_COUNT];
                try
                {
                    BaseKeyStoreEncryptionService hasher = new BaseKeyStoreEncryptionService()
                    {
                        /* Empty implementation
                         * (non-Javadoc)
                         * @see oracle.retail.stores.keystoreencryption.KeyStoreEncryptionServiceIfc#decrypt(byte[])
                         */
                        public byte[] decrypt(byte[] encryptedText) throws EncryptionServiceException { return null; }
                        /* Empty implementation
                         * (non-Javadoc)
                         * @see oracle.retail.stores.keystoreencryption.KeyStoreEncryptionServiceIfc#encrypt(byte[])
                         */
                        public byte[] encrypt(byte[] clearText) throws EncryptionServiceException { return null; }

                    };
                    hasher.setHashAlgorithmName("SHA-256");
                    SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(KEY_GENERATION_ALGORITHM);
                    KeySpec keySpec;
                    SecretKey secretKey;
                    int idx = 0;
                    byte[] hashKey;
                    byte[] encoded;
                    byte[] idxBytes;
                    keySpec = new PBEKeySpec(installerPhrase.toCharArray());
                    secretKey = keyFactory.generateSecret(keySpec);
                    while(idx < KEY_COUNT)
                    {
                        // convert index to byte array
                        idxBytes = String.valueOf(idx).getBytes();
                        // get secret key byte array
                        encoded = secretKey.getEncoded();
                        // combine encoded + idx bytes into one array
                        hashKey = new byte[encoded.length + idxBytes.length];
                        System.arraycopy(encoded, 0, hashKey, 0, encoded.length);
                        System.arraycopy(idxBytes, 0, hashKey, encoded.length, idxBytes.length);
                        // hash the result
                        hashKey = hasher.hash(hashKey);
                        // base 64
                        encryptionKeys[idx] = new String(Base64.encodeBase64(hashKey));
                        // take the last 12
                        if(encryptionKeys[idx].length() > 12)
                        {
                            encryptionKeys[idx] = encryptionKeys[idx].substring(encryptionKeys[idx].length() - 12);
                        }
                        idx++;
                    }
                }
                catch(Throwable t)
                {
                    // try again later?
                    encryptionKeys = null;
                    System.err.println("Could not generate encryption keys" + t);
                    throw new EncryptionServiceException("Could not generate encryption keys", t);
                }
            }
            else
            {
            	System.err.println("Key phrase is null");
                throw new EncryptionServiceException("Key phrase is null");
            }
        }
        return encryptionKeys;
    }

    /**
     * Retrieves the installer phrase from properties file.
     * @return
     * @throws EncryptionServiceException
     */
    protected String getInstallerPhrase() throws EncryptionServiceException
    {
        Properties props = new Properties();
        InputStream is = ClassLoader.getSystemResourceAsStream("config/" + APPLICATION_PROPERTIES);
        // if is null, then try again
        if(is == null)
        {
            is = getClass().getClassLoader().getResourceAsStream(APPLICATION_PROPERTIES);
        }
        String phrase = INSTALLER_PHRASE;
        try
        {
            //props.load(is);
            String encryptedPhrase = props.getProperty(INSTALLER_PHRASE);
            phrase = getDecodedString(encryptedPhrase);
        }
        catch(Exception e)
        {
            throw new EncryptionServiceException("Could not retrieve installer phrase", e);
        }
        return phrase;
    }

    /**
     * Get decrypted database password from the encrypted data.
     * @param encryptedText
     * @return
     */
    private String  getDecodedString(String encryptedText)
    {
        byte[] base64Bytes =   Base64.decodeBase64(encryptedText.getBytes());
        byte[] decBytes = new byte[base64Bytes.length];

        for (int i = 0; i < base64Bytes.length; i++)
        {
             byte xorByte = (byte)(base64Bytes[i] ^ 24);
             decBytes[i]= (byte)(xorByte - 12);
        }

        return new String(decBytes);

    }
}

