package com.tst;

/**
 * Custom exception for encryption service errors.
 */
public class EncryptionServiceException extends Exception {
    public EncryptionServiceException(String message) {
        super(message);
    }

    public EncryptionServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}