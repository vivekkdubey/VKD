
package com.vi;


public class SimKeyStoreEncryptionService extends BaseKeyStoreEncryptionService
{
    /** Logger used for debugging. */
    //protected static final Logger logger = Logger.getLogger(SimKeyStoreEncryptionService.class);
    /** Header length constant */
    protected static final int HEADER_LENGTH = 3;
    /** Simulated encryption client */
    protected SimulatedKeyStoreAndEncryptionClient client;
    /** Name of the cipher (encryption) algorithm.  Can be loaded from spring with different value. */
    protected String cipherName         = "DES";
    /** Value of the blocking used by the cipher.  Can be loaded from spring with different value. */
    protected String cipherMode         = "ECB";
    /** Value of the padding used by the cipher.  Can be loaded from spring with different value. */
    protected String cipherPadding      = "PKCS5PADDING";

    /**
     * Default constructor; instantiates and initializes the simulated client.
     */
    public SimKeyStoreEncryptionService()
    {
        client = new SimulatedKeyStoreAndEncryptionClient();
        client.setProviderName(SimulatedKeyStoreAndEncryptionClient.DEFAULT_PROVIDER_NAME);
        client.setCipherName(cipherName);
        client.setCipherMode(cipherMode);
        client.setCipherPadding(cipherPadding);
    }

    /**
     * Constructor. Instantiates and initializes the simulated client. This one
     * is used by the JCA connector, where the params are initialized through
     * Spring.
     * 
     * @param providerName
     * @param hashAlgorithmName
     */
    public SimKeyStoreEncryptionService(String providerName, String hashAlgorithmName)
    {
        client = new SimulatedKeyStoreAndEncryptionClient();
        client.setProviderName(providerName);
        client.setCipherName(cipherName);
        client.setCipherMode(cipherMode);
        client.setCipherPadding(cipherPadding);
        this.setHashAlgorithmName(hashAlgorithmName);
    }

    /**
     * This method calls the simulated key store to encrypt the clear text. It
     * then adds the meta data to the front of the byte array.
     * <p>
     * <b>NOTE:</b> This method's implementation is not recommended for use in
     * production. A stronger integration with a key store manager application
     * is preferred.
     * 
     * @param clearText
     * @return byte[] containing encrypted text
     * @exception EncryptionServiceException
     */
    public byte[] encrypt(byte[] clearText) throws EncryptionServiceException
    {
        try
        {
            // Construct a the header (metadata);  the header contain three bytes which are the ASCI
            // value of the length of the key id.  In this example, the key id is
            // is just an integer index into the array that contains the list of encription keys.
            // The Byte array that is returned has three parts:
            //    | Meta Data length (3 bytes long) | Key ID (variable length) | Encrypted Data |
            SimKeyStoreCryptogram cryptogram = client.encrypt(clearText);
            String sID                       = Integer.toString(cryptogram.getKeyId());
            String sIDLen                    = Integer.toString(sID.length());

            // Padd the metadata length with leading zeros
            StringBuffer bIDLen              = new StringBuffer();
            int padLength                    = HEADER_LENGTH - sIDLen.length();
            for(int i = 0; i < padLength; i++)
            {
                bIDLen.append("0");
            }
            // Add the metadata length and metadata (keyID) to string buffer
            bIDLen.append(sIDLen);
            bIDLen.append(sID);

            // Combine the metadata and key with actual encrypted data
            byte[] header = bIDLen.toString().getBytes();
            byte[] data   = cryptogram.getData();
            byte[] both   = new byte[header.length + data.length];
            for(int i = 0; i < header.length; i++)
            {
                both[i] = header[i];
            }
            int diff = header.length;
            for(int i = 0; i < data.length; i++)
            {
                both[i + diff] = data[i];
            }

            // Return total byte array
            return both;
        }
        catch (Exception e)
        {
            System.err.println("Error encrypting text" + e);
            throw new EncryptionServiceException("Error encrypting text", e);
        }
    }

    /**
     * This method calls the simulated key store and encryption service to
     * decrypt the clear text.
     * <p>
     * <b>NOTE:</b> This method's implementation is not recommended for use in
     * production. A stronger integration with a key store manager application
     * is preferred.
     * 
     * @param encryptedText
     * @return byte[] containing the original clear text
     * @exception EncryptionServiceException
     */
    public byte[] decrypt(byte[] encryptedText) throws EncryptionServiceException
    {
        try
        {
            // Break up the byte array into its three parts:
            //    | Meta Data length (3 bytes long) | Key ID (variable length) | Encrypted Data |

            // Get the length bytes from the front of the byte array
            byte[] metaDataLen = new byte[HEADER_LENGTH];
            for(int i = 0; i < HEADER_LENGTH; i++)
            {
                metaDataLen[i] = encryptedText[i];
            }

            // Convert the byte array to character array
            byte[] bData = new byte[HEADER_LENGTH];
            for (int i = 0; i < HEADER_LENGTH; i++)
            {
                bData[i] = metaDataLen[i];
            }
            // Convert the character array to a string, then the integer lenthr value
            int intLen = Integer.parseInt(new String(bData));

            // Get the key id and convert it to the key id integer
            bData = new byte[intLen];
            for(int i = 0; i < intLen; i++)
            {
                bData[i] = encryptedText[i + HEADER_LENGTH];
            }
            int keyID = Integer.parseInt(new String(bData));

            // Copy the data portion of the encryted text into its own byte array
            int totalHeaderLen = HEADER_LENGTH + intLen;
            int dataLength     = encryptedText.length - totalHeaderLen;
            byte[] data = new byte[dataLength];
            for(int i = 0; i < dataLength; i++)
            {
                data[i] = encryptedText[i + totalHeaderLen];
            }

            // Build the cryptogram and request decryption.
            SimKeyStoreCryptogram cryptogram = new SimKeyStoreCryptogram(data, keyID);
            byte[] clearText = client.decrypt(cryptogram);
            return clearText;
        }
        catch (Exception e)
        {
        	System.err.println("Error decrypting text" + e);
            throw new EncryptionServiceException("Error decrypting text", e);
        }
    }
    /**
     * @return Returns the cipherName.
     */
    public String getCipherName()
    {
        return cipherName;
    }

    /**
     * @param cipherName The cipherName to set.
     */
    public void setCipherName(String cipherName)
    {
        this.cipherName = cipherName;
    }

    /**
     * @return Returns the mode.
     */
    public String getCipherMode()
    {
        return cipherMode;
    }

    /**
     * @param mode The mode to set.
     */
    public void setCipherMode(String mode)
    {
        this.cipherMode = mode;
    }

    /**
     * @return Returns the padding.
     */
    public String getCipherPadding()
    {
        return cipherPadding;
    }

    /**
     * @param padding The padding to set.
     */
    public void setCipherPadding(String padding)
    {
        this.cipherPadding = padding;
    }

    /**
     * @param providerName The provider name to set
     */
    @Override
    public void setProviderName(String providerName)
    {
        super.setProviderName(providerName);
        client.setProviderName(providerName);
    }

    /**
     * @param providerName The provider name to get
     */
    @Override
    public String getProviderName()
    {
        return client.getProviderName();
    }
}

