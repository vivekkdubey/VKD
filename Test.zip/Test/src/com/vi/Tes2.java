package com.vi;

import org.apache.commons.codec.binary.Base64;

public class Tes2 {

	public static void main(String[] args) {
		String original = "Hello Vivek!";

		// Encode
		byte[] encodedBytes = Base64.encodeBase64(original.getBytes());
		String encodedString = new String(encodedBytes);
		System.out.println("Encoded: " + encodedString);

		// Decode
		byte[] decodedBytes = Base64.decodeBase64(encodedBytes);
		String decodedString = new String(decodedBytes);
		System.out.println("Decoded: " + decodedString);
	}

}
