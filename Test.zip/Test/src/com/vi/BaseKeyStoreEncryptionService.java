package com.vi;

import java.security.MessageDigest;

public abstract class BaseKeyStoreEncryptionService implements KeyStoreEncryptionServiceIfc
{
    protected String providerName;
   
    protected String hashAlgorithmName = "SHA-256";

    public BaseKeyStoreEncryptionService()
    {
    }

    public byte[] hash(byte[] clearText) 
    {
        try
        {
            MessageDigest digest = MessageDigest.getInstance(getHashAlgorithmName());
            assert digest != null : "No such digest algorithm: " + getHashAlgorithmName();
            byte[] hash = digest.digest(clearText);
            return hash;
        }
        catch (Exception ex)
        {
            System.out.println("Error hashing text" + ex);
        }
		return clearText;
    }

    /**
     * Gets the name of hash algorithm. This value is usually set by Spring.
     * The value is in the spring.properties file.
     * 
     * @return String
     */
    public String getHashAlgorithmName()
    {
        return hashAlgorithmName;
    }

    /**
     * Sets the name of hash algorithm. This value is usually set by Spring.
     * The value is in the spring.properties file.
     * 
     * @param algorithmName
     */
    public void setHashAlgorithmName(String algorithmName)
    {
        hashAlgorithmName = algorithmName;
    }

    /**
     * @return Returns the providerName.
     */
    public String getProviderName()
    {
        return providerName;
    }

    /**
     * @param providerName The providerName to set.
     */
    public void setProviderName(String providerName)
    {
        this.providerName = providerName;
    }
}