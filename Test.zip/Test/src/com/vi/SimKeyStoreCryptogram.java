/* ===========================================================================
* Copyright (c) 2007, 2010, Oracle and/or its affiliates. All rights reserved. 
 * ===========================================================================
 * $Header: rgbustores/applications/simkeystore/src/oracle/retail/stores/simkeystore/client/SimKeyStoreCryptogram.java /main/4 2010/01/03 18:06:03 abondala Exp $
 * ===========================================================================
 * NOTES
 * <other useful comments, qualifications, etc.>
 *
 * MODIFIED    (MM/DD/YY)
 *    abondala  01/03/10 - update header date
 *
 * ===========================================================================
 * $Log:
 *  1    360Commerce 1.0         11/1/2007 2:22:47 PM   Jack G. Swan    Add
 *       simulated key store implementation.
 * $
 * ===========================================================================
 */
package com.vi;

import java.io.Serializable;
import java.util.Arrays;

/**
 * A Cryptogram represents an encrypted value paired with the id of the key used
 * to encrypt the value.  The id can be used to request decryption using the 
 * appropriate key from the key store.
 * 
 */
public class SimKeyStoreCryptogram implements Serializable
{

    /** serial id */
    private static final long serialVersionUID = 6210896708648106607L;

    /**
     * The encrypted data stored in an array of bytes.
     */
    private byte[] encryptedData;
    
    /**
     * A simple id of the encrypt/decrypt key in the key store.
     */
    private int keyId;
    
    /**
     * Create a cryptogram given the encrypted data, and the key id.
     * 
     * @param data encrypted data 
     * @param keyId id of the key in the key store
     */
    public SimKeyStoreCryptogram(byte[] data, int keyId) 
    {
        this.encryptedData = data;
        this.keyId = keyId;
    }
    
    /**
     * return the encrypted data of the cryptogram.
     * 
     * @return byte array of encrypted data
     */
    public byte[] getData()
    {
        return this.encryptedData;
    }
    
    /**
     * return the key id used to encrypt the value.
     * 
     * @return key id 
     */
    public int getKeyId()
    {
        return this.keyId;
    }
    
    /**
     * Generate a hashCode based on the hashCode of the keyID and the encrypted data.
     * @return hashCode based on contents.
     */
    public int hashCode()
    {
        int hashCode = 1;
        Integer id = new Integer(keyId);
        hashCode += id.hashCode();
        if (encryptedData != null)
        {
            for(int i=0; i < encryptedData.length; i++)
            {
                hashCode += encryptedData[i];
            }
        }
        return hashCode;
    }

    /**
     * Deep equals based on key id and encrypted data.
     * @param other The object to test for equality
     * @return if other is equal to this.
     */
    public boolean equals(Object other)
    {
        if (other instanceof SimKeyStoreCryptogram)
        {
            SimKeyStoreCryptogram o = (SimKeyStoreCryptogram) other;
            if (keyId == o.keyId) 
            {
                return Arrays.equals(encryptedData,o.encryptedData);
            }
        }
        
        return false;
    }
}
