package com.vi.pos;
import java.io.*;
import java.util.*;

public class WindowsCpuMonitor {

    public static void main(String[] args) throws Exception {

        String command =
                "Get-Counter " +
                "'\\Processor(_Total)\\% Processor Time' " +
                "-SampleInterval 60 " +
                "-MaxSamples 10 | " +

                "Select-Object -ExpandProperty CounterSamples | " +
                "Select-Object -ExpandProperty CookedValue";

        ProcessBuilder pb = new ProcessBuilder(
                "powershell.exe",
                "-NoProfile",
                "-Command",
                command
        );

        Process process = pb.start();

        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(
                                process.getInputStream()
                        )
                );

        List<Double> samples = new ArrayList<>();

        String line;

        while ((line = reader.readLine()) != null) {

            line = line.trim();

            if (!line.isEmpty()) {
                samples.add(
                        Double.parseDouble(line)
                );
            }
        }

        process.waitFor();

        if (samples.isEmpty()) {
            System.out.println("No CPU data received.");
            return;
        }

        double average =
                samples.stream()
                        .mapToDouble(Double::doubleValue)
                        .average()
                        .orElse(0);

        double maximum =
                samples.stream()
                        .mapToDouble(Double::doubleValue)
                        .max()
                        .orElse(0);

        double minimum =
                samples.stream()
                        .mapToDouble(Double::doubleValue)
                        .min()
                        .orElse(0);

        System.out.println(
                "CPU samples     : " + samples.size()
        );

        System.out.printf(
                "10-min Average  : %.2f%%%n",
                average
        );

        System.out.printf(
                "10-min Maximum  : %.2f%%%n",
                maximum
        );

        System.out.printf(
                "10-min Minimum  : %.2f%%%n",
                minimum
        );
    }
}