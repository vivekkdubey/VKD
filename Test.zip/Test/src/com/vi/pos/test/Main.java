package com.vi.pos.test;

import java.util.List;

import com.vi.pos.pojo.Store;
import com.vi.pos.pojo.StoreRepository;

public class Main {

    public static void main(String[] args) {

        StoreRepository repository = new StoreRepository();

        List<Store> stores = repository.loadStores();

        for (Store store : stores) {
            System.out.println(store);
        }
    }
}