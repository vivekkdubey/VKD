package com.vi.pos;
import java.lang.management.ManagementFactory;
import com.sun.management.OperatingSystemMXBean;

import java.util.*;
import java.util.concurrent.*;

public class CpuMonitor {

    private static final int INTERVAL_SECONDS = 60;
    private static final int HISTORY_MINUTES = 10;

    private static final Deque<CpuSample> cpuHistory =
            new ArrayDeque<>();

    public static void main(String[] args) {

        ScheduledExecutorService scheduler =
                Executors.newScheduledThreadPool(1);

        scheduler.scheduleAtFixedRate(
                CpuMonitor::collectCpu,
                0,
                INTERVAL_SECONDS,
                TimeUnit.SECONDS
        );
    }

    private static void collectCpu() {

        OperatingSystemMXBean osBean =
                (OperatingSystemMXBean)
                        ManagementFactory.getOperatingSystemMXBean();

        double cpu =
                osBean.getCpuLoad() * 100;

        CpuSample sample =
                new CpuSample(
                        System.currentTimeMillis(),
                        cpu
                );

        synchronized (cpuHistory) {

            cpuHistory.addLast(sample);

            // Keep only last 10 minutes
            long cutoff =
                    System.currentTimeMillis()
                    - (HISTORY_MINUTES * 60 * 1000L);

            while (!cpuHistory.isEmpty()
                    && cpuHistory.peekFirst().timestamp < cutoff) {

                cpuHistory.removeFirst();
            }
        }

        printLast10Minutes();
    }

    private static void printLast10Minutes() {

        synchronized (cpuHistory) {

            System.out.println(
                    "\nCPU utilization - Last 10 minutes"
            );

            for (CpuSample sample : cpuHistory) {

                Date date =
                        new Date(sample.timestamp);

                System.out.printf(
                        "%tT  CPU: %.2f%%%n",
                        date,
                        sample.cpu
                );
            }
        }
    }

    static class CpuSample {

        long timestamp;
        double cpu;

        CpuSample(long timestamp, double cpu) {

            this.timestamp = timestamp;
            this.cpu = cpu;
        }
    }
}