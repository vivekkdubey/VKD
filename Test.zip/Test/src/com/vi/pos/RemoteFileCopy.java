package com.vi.pos;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.vi.pos.pojo.Store;
import com.vi.pos.pojo.StoreRepository;

public class RemoteFileCopy {

    private static final String SOURCE_FILE = "C:\\Deploy\\app.jar";
    private static final String REMOTE_FOLDER = "D$\\Deploy";
    private static final String USERNAME = ".\\oretail";
    private static final String PASSWORD = "Hello123";

    public static void main(String[] args) {

       /* List<String> servers = Arrays.asList(
                "SERVER01",
                "SERVER02",
                "SERVER03",
                "SERVER04",
                // ...
                "SERVER100"
        );*/
        StoreRepository repository = new StoreRepository();
        List<Store> stores = repository.loadStores();

        int parallelCopies = 10;

        ExecutorService executor =
                Executors.newFixedThreadPool(parallelCopies);

        List<Future<CopyResult>> futures = new ArrayList<>();

      /*  for (String server : servers) {
            futures.add(executor.submit(() ->
                    copyFile(server)
            ));
        }
	*/
        stores.parallelStream().forEach(store -> {
            String str = store.getIdStrRt();
            String name = store.getVmName();

            futures.add(executor.submit(() ->
            copyFile(str,name)));
            // Check Windows Performance
        });
        executor.shutdown();

        int success = 0;
        int failed = 0;

        for (Future<CopyResult> future : futures) {
            try {
                CopyResult result = future.get();

                if (result.success) {
                    success++;
                    System.out.println(
                            "[SUCCESS] " + result.server
                    );
                } else {
                    failed++;
                    System.out.println(
                            "[FAILED] " + result.server +
                            " : " + result.message
                    );
                }

            } catch (Exception e) {
                failed++;
                System.out.println(
                        "[ERROR] " + e.getMessage()
                );
            }
        }

        System.out.println("\n==========================");
        System.out.println("Total   : " + stores.size());
        System.out.println("Success : " + success);
        System.out.println("Failed  : " + failed);
        System.out.println("==========================");
    }

    private static CopyResult copyFile(String str, String server) {

        String remotePath =
                "\\\\" + server + "\\" +
                REMOTE_FOLDER.replace("\\", "\\\\");

        try {

            // Connect/authenticate to remote server
            authenticate(server);

            Path source = Paths.get(SOURCE_FILE);

            Path destination =
                    Paths.get(remotePath + "\\app.jar");

            Files.copy(
                    source,
                    destination,
                    StandardCopyOption.REPLACE_EXISTING
            );

            return new CopyResult(
                    server,
                    true,
                    "File copied successfully"
            );

        } catch (Exception e) {

            return new CopyResult(
                    server,
                    false,
                    e.getMessage()
            );
        }
    }

    private static void authenticate(String server)
            throws IOException {

        ProcessBuilder pb = new ProcessBuilder(
                "cmd.exe",
                "/c",
                "net",
                "use",
                "\\\\" + server + "\\C$",
                "/user:" + USERNAME,
                PASSWORD
        );

        Process process = pb.start();

        try {
            int exitCode = process.waitFor();

            if (exitCode != 0) {
                throw new IOException(
                        "Authentication failed"
                );
            }

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException(
                    "Authentication interrupted", e
            );
        }
    }

    static class CopyResult {

        String server;
        boolean success;
        String message;

        CopyResult(
                String server,
                boolean success,
                String message) {

            this.server = server;
            this.success = success;
            this.message = message;
        }
    }
}