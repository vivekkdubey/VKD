package com.vi.pos;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

public class WindowsServerMonitor {

    private static final int THREADS = 20;
    private static final int TIMEOUT_SECONDS = 20;

    public static void main(String[] args) throws Exception {

        // ---------------------------------------------------------
        // Server list
        // First entry = LOCAL server
        // Remaining entries = remote servers
        // ---------------------------------------------------------

        List<String> servers = new ArrayList<>();

        servers.add("LOCAL");

        servers.addAll(Arrays.asList(
                "VIVEK-PC",
                "VIVEK-PC",
                "VIVEK-PC"
        ));

        ExecutorService executor =
                Executors.newFixedThreadPool(THREADS);

        List<Future<ServerMetrics>> futures = new ArrayList<>();

        long startTime = System.currentTimeMillis();

        // ---------------------------------------------------------
        // Submit all servers
        // ---------------------------------------------------------

        for (String server : servers) {

            Future<ServerMetrics> future =
                    executor.submit(() -> monitorServer(server));

            futures.add(future);
        }

        // ---------------------------------------------------------
        // Collect results
        // ---------------------------------------------------------

        List<ServerMetrics> results = new ArrayList<>();

        for (Future<ServerMetrics> future : futures) {

            try {

                ServerMetrics result =
                        future.get(
                                TIMEOUT_SECONDS,
                                TimeUnit.SECONDS
                        );

                results.add(result);

            } catch (TimeoutException e) {

                future.cancel(true);

                results.add(
                        new ServerMetrics(
                                "UNKNOWN",
                                0,
                                Collections.emptyMap(),
                                "TIMEOUT"
                        )
                );

            } catch (Exception e) {

                results.add(
                        new ServerMetrics(
                                "UNKNOWN",
                                0,
                                Collections.emptyMap(),
                                "ERROR"
                        )
                );
            }
        }

        executor.shutdown();

        // ---------------------------------------------------------
        // Display results
        // ---------------------------------------------------------

        printResults(results);

        long elapsed =
                System.currentTimeMillis() - startTime;

        System.out.println();
        System.out.println(
                "Monitoring completed in "
                        + elapsed
                        + " ms"
        );
    }


    // =============================================================
    // Monitor server
    // =============================================================

    private static ServerMetrics monitorServer(
            String server) throws Exception {

        if ("LOCAL".equalsIgnoreCase(server)) {

            return monitorLocalServer();

        } else {

            return monitorRemoteServer(server);
        }
    }


    // =============================================================
    // LOCAL SERVER
    // =============================================================

    private static ServerMetrics monitorLocalServer()
            throws Exception {

        String computerName =
                System.getenv("COMPUTERNAME");

        String command =
                "Get-Counter " +
                "'\\Processor(_Total)\\% Processor Time' " +
                "-SampleInterval 1 -MaxSamples 1 | " +
                "Select-Object -ExpandProperty CounterSamples | " +
                "Select-Object -ExpandProperty CookedValue";

        String cpuOutput =
                executePowerShell(command);

        double cpu =
                Double.parseDouble(
                        cpuOutput.trim()
                );

        Map<String, Double> disks =
                getLocalDisks();

        return new ServerMetrics(
                computerName,
                cpu,
                disks,
                "UP"
        );
    }


    // =============================================================
    // LOCAL DISKS
    // =============================================================

    private static Map<String, Double> getLocalDisks()
            throws Exception {

        String command =
                "Get-CimInstance Win32_LogicalDisk " +
                "-Filter \"DriveType=3\" | " +
                "ForEach-Object { " +
                "$used = " +
                "(($_.Size - $_.FreeSpace) / $_.Size) * 100; " +
                "$_.DeviceID + '=' + " +
                "[math]::Round($used,2) " +
                "}";

        String output =
                executePowerShell(command);

        return parseDiskOutput(output);
    }


    // =============================================================
    // REMOTE SERVER
    // =============================================================

    private static ServerMetrics monitorRemoteServer(
            String server) throws Exception {

        String psScript =
                "Invoke-Command " +
                "-ComputerName '" + server + "' " +
                "-ScriptBlock {" +

                "$cpu = " +
                "(Get-Counter " +
                "'\\Processor(_Total)\\% Processor Time' " +
                "-SampleInterval 1 " +
                "-MaxSamples 1).CounterSamples.CookedValue;" +

                "$disks = " +
                "Get-CimInstance Win32_LogicalDisk " +
                "-Filter \"DriveType=3\" | " +

                "ForEach-Object { " +

                "$used = " +
                "(($_.Size - $_.FreeSpace) / $_.Size) * 100;" +

                "$_.DeviceID + '=' + " +
                "[math]::Round($used,2)" +

                "};" +

                "Write-Output ('CPU=' + " +
                "[math]::Round($cpu,2));" +

                "$disks | ForEach-Object {" +
                "Write-Output $_" +
                "}" +

                "}";

        try {

            String output =
                    executePowerShell(psScript);

            double cpu = 0;

            Map<String, Double> disks =
                    new LinkedHashMap<>();

            for (String line :
                    output.split("\\r?\\n")) {

                line = line.trim();

                if (line.startsWith("CPU=")) {

                    cpu =
                            Double.parseDouble(
                                    line.substring(4)
                            );

                } else if (
                        line.matches(
                                "[A-Z]:=.*")) {

                    String[] parts =
                            line.split("=");

                    disks.put(
                            parts[0],
                            Double.parseDouble(
                                    parts[1]
                            )
                    );
                }
            }

            return new ServerMetrics(
                    server,
                    cpu,
                    disks,
                    "UP"
            );

        } catch (Exception e) {

            return new ServerMetrics(
                    server,
                    0,
                    Collections.emptyMap(),
                    "DOWN"
            );
        }
    }


    // =============================================================
    // PowerShell execution
    // =============================================================

    private static String executePowerShell(
            String command) throws Exception {

        ProcessBuilder pb =
                new ProcessBuilder(
                        "powershell.exe",
                        "-NoProfile",
                        "-NonInteractive",
                        "-ExecutionPolicy",
                        "Bypass",
                        "-Command",
                        command
                );

        Process process = pb.start();

        String output =
                readStream(
                        process.getInputStream()
                );

        String error =
                readStream(
                        process.getErrorStream()
                );

        boolean completed =
                process.waitFor(
                        TIMEOUT_SECONDS,
                        TimeUnit.SECONDS
                );

        if (!completed) {

            process.destroyForcibly();

            throw new TimeoutException(
                    "PowerShell timeout"
            );
        }

        if (process.exitValue() != 0) {

            throw new RuntimeException(
                    error
            );
        }

        return output;
    }


    // =============================================================
    // Read stream
    // =============================================================

    private static String readStream(
            InputStream stream)
            throws IOException {

        BufferedReader reader =
                new BufferedReader(
                        new InputStreamReader(stream)
                );

        return reader.lines()
                .collect(Collectors.joining("\n"));
    }


    // =============================================================
    // Parse disk information
    // =============================================================

    private static Map<String, Double>
    parseDiskOutput(String output) {

        Map<String, Double> result =
                new LinkedHashMap<>();

        for (String line :
                output.split("\\r?\\n")) {

            line = line.trim();

            if (line.matches("[A-Z]:=.*")) {

                String[] parts =
                        line.split("=");

                result.put(
                        parts[0],
                        Double.parseDouble(
                                parts[1]
                        )
                );
            }
        }

        return result;
    }


    // =============================================================
    // Display
    // =============================================================

    private static void printResults(
            List<ServerMetrics> results) {

        System.out.println();
        System.out.println(
                "=============================================================="
        );

        System.out.printf(
                "%-20s %-10s %-12s %-20s%n",
                "SERVER",
                "STATUS",
                "CPU %",
                "DISKS"
        );

        System.out.println(
                "=============================================================="
        );

        for (ServerMetrics r : results) {

            String disks =
                    r.disks.entrySet()
                            .stream()
                            .map(e ->
                                    e.getKey()
                                    + "="
                                    + e.getValue()
                                    + "%")
                            .collect(
                                    Collectors.joining(
                                            ", "
                                    )
                            );

            System.out.printf(
                    "%-20s %-10s %-12.2f %-20s%n",
                    r.server,
                    r.status,
                    r.cpu,
                    disks
            );
        }

        System.out.println(
                "=============================================================="
        );
    }


    // =============================================================
    // Result object
    // =============================================================

    static class ServerMetrics {

        String server;
        double cpu;
        Map<String, Double> disks;
        String status;

        ServerMetrics(
                String server,
                double cpu,
                Map<String, Double> disks,
                String status) {

            this.server = server;
            this.cpu = cpu;
            this.disks = disks;
            this.status = status;
        }
    }
}