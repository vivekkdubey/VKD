package com.vi.pos.pojo;
public class Store {

    private String idStrRt;
    private String vmIp;
    private String vmName;

    public String getIdStrRt() {
        return idStrRt;
    }

    public void setIdStrRt(String idStrRt) {
        this.idStrRt = idStrRt;
    }

    public String getVmIp() {
        return vmIp;
    }

    public void setVmIp(String vmIp) {
        this.vmIp = vmIp;
    }

    public String getVmName() {
        return vmName;
    }

    public void setVmName(String vmName) {
        this.vmName = vmName;
    }

    @Override
    public String toString() {
        return idStrRt + " | " + vmIp + " | " + vmName;
    }
}