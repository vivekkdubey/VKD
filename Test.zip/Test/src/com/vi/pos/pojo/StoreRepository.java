package com.vi.pos.pojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StoreRepository {

    public List<Store> loadStores() {

        List<Store> stores = new ArrayList<>();

        String sql = "SELECT id_str_rt, vm_ip, vm_name FROM pa_str_rtl ORDER BY id_str_rt";

        try (Connection conn = OracleDBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Store store = new Store();

                store.setIdStrRt(rs.getString("id_str_rt"));
                store.setVmIp(rs.getString("vm_ip"));
                store.setVmName(rs.getString("vm_name"));

                stores.add(store);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return stores;
    }
}