/* ===========================================================================
* Copyright (c) 2007, 2010, Oracle and/or its affiliates. All rights reserved. 
 * ===========================================================================
 * $Header: rgbustores/modules/encryptionclient/src/oracle/retail/stores/keystoreencryption/EncryptionServiceException.java /main/3 2010/01/04 15:10:39 abondala Exp $
 * ===========================================================================
 * NOTES
 * <other useful comments, qualifications, etc.>
 *
 * MODIFIED    (MM/DD/YY)
 *    abondala  01/04/10 - update header date
 *
 * ===========================================================================
 * $Log:
 *  1    360Commerce 1.0         11/1/2007 2:37:02 PM   Jack G. Swan    Add key
 *        store interface and encryption exception.
 * $
 * ===========================================================================
 */
package com.vi;

/**
 *  This exception will thrown from classes the implement KeyStoreEncyiptionServiceIfc.  The
 *  original exception can be obtained by calling getCause. 
 */
public class EncryptionServiceException extends Exception
{

    /**  */
    private static final long serialVersionUID = 2687104537166320899L;

    /**
     * 
     */
    public EncryptionServiceException()
    {
    }

    /**
     * @param message
     */
    public EncryptionServiceException(String message)
    {
        super(message);
    }

    /**
     * @param cause
     */
    public EncryptionServiceException(Throwable cause)
    {
        super(cause);
    }

    /**
     * @param message
     * @param cause
     */
    public EncryptionServiceException(String message, Throwable cause)
    {
        super(message, cause);
    }

}
