package com.vi;

public interface KeyStoreEncryptionServiceIfc
{
   

    public byte[] encrypt(byte[] clearText)  throws EncryptionServiceException;

    public byte[] decrypt(byte[] encryptedText) throws EncryptionServiceException ;

    public byte[] hash(byte[] clearText)  throws EncryptionServiceException; 

}