package com.vi;

import java.util.Arrays;
import java.util.List;

public class Test1 extends BaseKeyStoreEncryptionService{
	public static void main(String[] h) {
		List<Integer> numbers = Arrays.asList(2,3,4,5,6,50,7);
		int min = numbers.get(0);
		System.out.println("===="+min);
		for(int i = 0 ; i<numbers.size();i++) {
			if(numbers.get(i)>min)
				min=numbers.get(i);
		}
		System.out.println("Min : "+min);
		
		
		
		List<Integer> numbers1 = Arrays.asList(2,3,1,4,5,6,50,7);
		System.out.println(numbers1.stream().min(Integer::compareTo));
		String newPassword ="VF12";
		
		changeEmployeePassword( newPassword) ;
		
		
	}
	
	public static  void changeEmployeePassword(String newPassword) 
    {
		SimKeyStoreEncryptionService encryptionSvc = new SimKeyStoreEncryptionService() ;
        //byte[] oldPwdBytes = null;
        byte[] newPwdBytes = null;

        try
        {
           // oldPwdBytes = encryptionSvc.hash(oldPassword.getBytes());
            newPwdBytes = encryptionSvc.hash(newPassword.getBytes());
        }
        catch (Exception ce)
        {
            // Crypto failed, throw exception
            System.err.println(
                    "Failed to change password for employee ");
            //throw new EmployeeNotFoundException();
        }

       
    }

	@Override
	public byte[] encrypt(byte[] clearText) throws EncryptionServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] decrypt(byte[] encryptedText) throws EncryptionServiceException {
		// TODO Auto-generated method stub
		return null;
	}
}
